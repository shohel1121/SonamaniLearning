# সোনামণি শেখা — Android App Project

এই প্রকল্পে:
- বাংলা ও English বর্ণমালা আলাদা করা হয়েছে
- বাংলা/English কবিতা আলাদা অংশে আছে
- সংখ্যা ১–১০০ শেখার ব্যবস্থা আছে
- Settings-এ ভয়েস, রং, ডিজাইন ও Auto Voice আছে
- নিজের বর্ণ/শব্দ/কবিতা/সংখ্যা/ছবি দিয়ে এক বা একাধিক HTML ফাইল তৈরি করা যায়
- Android WebView bridge দিয়ে তৈরি HTML ফাইল Downloads-এ সংরক্ষণ করা যায়

## APK বানানোর নিয়ম
Android Studio-তে এই ফোল্ডারটি Open করে Gradle Sync করুন এবং:
Build > Build APK(s)

এই পরিবেশে Android SDK/Gradle build tool নেই, তাই এখানে সরাসরি APK compile করা হয়নি; source project প্রস্তুত করা হয়েছে।
